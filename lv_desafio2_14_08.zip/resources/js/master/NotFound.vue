<template>
  <p>
    Ops! Página não encontrada
  </p>
</template>
<script>

export default {
  name: 'NotFound'
};
</script>

<style scoped>
p {
    font-weight: bold;
    font-size: 50px;
    text-align: center;
    color: #f10b0b;
}
</style>